import c_WSF
import zarr
import h5py
from pathlib import Path, PureWindowsPath
import numpy as np
from time import time, sleep
import os
import pickle
import datetime
from concurrent.futures import ProcessPoolExecutor, as_completed
from itertools import islice
import rclone
import t_zarr
import json
from shutil import rmtree
from sys import argv


def process_time_sync_file(s3_config,
                           s3_target,
                           poly_pixel_dict,
                           wsf_where
                           ):
    
    # Split the tile, year and doy out of the file name
    split_file = s3_target[1].split('.')
    tile = split_file[3]
    year = split_file[1]
    doy = split_file[2]
    # Form a datetime object
    date_obj = datetime.datetime(year=int(year), month=1, day=1) + (datetime.timedelta(days=int(doy)) -1)
    
    # Results dictionaries
    poly_results = {}
    wsf_results = {}
    # For each polygon ID
    for poly_id in poly_pixel_dict.keys():
        poly_results[poly_id] = {}
    
    # Get the h5 file from s3
    rclone.with_config(s3_config).run_cmd(command="copy", 
                                    extra_args=[f"ceph:vnp46a2/{tile}/{year}/{s3_target[1]}", f"/app/temp_data/"])   
    
    # Open the file
    h5file = h5py.File(Path(f"/app/temp_data/{s3_target[1]}"))
    
    # For each data field
    for data_field in h5file['HDFEOS']['GRIDS']['VNP_Grid_DNB']['Data Fields'].keys():
        # Get the dataset as a numpy array
        dataset = np.array(h5file["HDFEOS"]["GRIDS"]['VNP_Grid_DNB']['Data Fields'][data_field])
        # Get the wsf subset as a 1D field
        wsf_results[data_field] = dataset[wsf_where].reshape(-1)
        # For each polygon ID
        for poly_id in poly_pixel_dict.keys():
            poly_results[poly_id][data_field] = []
            # For each pixel coordinate pair
            for pix_h, pix_v in zip(poly_pixel_dict[poly_id]["pixel_hs"],
                                    poly_pixel_dict[poly_id]["pixel_vs"]):
                # Append the value for the pixel
                poly_results[poly_id][data_field].append(dataset[pix_v][pix_h])
    
    # Delete the tile file copy
    os.remove(f"/app/temp_data/{s3_target[1]}")

    # Return the completed results dictionary and date object
    return date_obj, poly_results, wsf_results, s3_target


def chunk_files(files_list, chunk=20):
    it = iter(files_list)
    while True:
        piece = list(islice(it, chunk))
        if piece:
            yield piece
        else:
            return


def create_s3_dir(config, uri):

    rclone.with_config(config).run_cmd(command="mkdir", extra_args=[uri, "--quiet"])


# Function to return the time difference from a start time until now
def time_diff(start_time):

    return np.around(time() - start_time, decimals=2)


def main(tile_file, wsf_eq_threshold=0):
    
    # SETUP
    
    # Start the clock
    stime = time()     
    
    # List for tiles to be downloaded
    tile_list = []
    
    # Import the list of tiles
    with open(Path(f"/app/{tile_file}.txt"), 'r') as f:
        for line in f:
            tile_list.append(line.strip('\n'))
    
    # Update
    print(f"Starting zarr conversion of {len(tile_list)} tiles. Configuring s3.")
    
    # Get s3 secrets
    with open(Path("/app/s3/s3accesskey.txt"), 'r') as f:
        for line in f:
            s3_access_key = str(line.strip()[4:-1])
            break
            
    with open(Path("/app/s3/s3secretkey.txt"), 'r') as f:
        for line in f:
            s3_secret_key = str(line.strip()[4:-1])
            break
    
    # Form a remote configuration for rclone
    cfg = """[ceph]
    type = s3
    provider = Ceph Object Storage
    endpoint = http://rook-ceph-rgw-nautiluss3.rook
    access_key_id = {0}
    secret_access_key = {1}
    region =
    nounc = true"""
    
    # Add the s3 secrets to the configuration
    cfg = cfg.format(s3_access_key, s3_secret_key)
    
    # Make s3 "directories" for the output data
    for new_dir in ["ceph:zarrs", "ceph:zarrs/wsf", "ceph:zarrs/fua"]:
        create_s3_dir(cfg, new_dir)
       
    # Update
    print(f"Configured s3 in {time_diff(stime)}. Loading FUA polygon dictionaries.")
    ptime = time()   
    
    # Load the poly -> tile -> pixel dictionary
    with open(Path("/app/poly_to_tile_to_pixel.json"), 'r') as f:
        poly_tile_pixel = json.load(f)
    
    # Load the tile -> poly dictionary
    with open(Path("/app/tile_to_poly.json"), 'r') as f:
        tile_poly = json.load(f)
    
    # Update
    print(f"Loaded FUA polygon dictionaries {time_diff(ptime)}. Starting per-tile processing.")
    ptime = time()   
        
    # For each tile
    for tile in tile_list:
        # Update
        print(f"Processing tile {tile}. Searching for existing files.")
        ptime = time()
        # Retrieve existing zarr file for tile
        existing_files_ls = rclone.with_config(cfg).run_cmd(command="ls", 
                                                            extra_args=[f"ceph:zarrs/wsf/wsf_{tile}.zarr/"])
        # If the zarr file exists
        if len(existing_files_ls['out'].decode("utf-8")) > 0:
            # Print message
            print(f"Completed zarr file found for {tile}. Skipping processing.")        
        # Dictionary for the dates and tile addresses in s3
        date_dict = {}
        # Retrieve existing files for tile
        existing_files_ls = rclone.with_config(cfg).run_cmd(command="ls", extra_args=[f"ceph:vnp46a2/{tile}/", "--include", "VNP46A2*.h5"])
        # Counter for dates (to preshape zarr arrays)
        date_count = 0
        # For each existing file
        for existing_file in (existing_files_ls['out'].decode("utf-8")).split(' '):
            # Filter other stuff out of the ls response content
            if "VNP46A2" in existing_file:     
                # Increment date count
                date_count += 1
                # Split out the year from the path
                file_name = existing_file.strip().split('/')[1]                
                # Split the year and doy out of the file name
                split_file = file_name.split('.')
                year = split_file[1]
                doy = split_file[2]
                # Add to dictionary
                if year not in date_dict.keys():
                    date_dict[year] = {}
                if doy not in date_dict[year].keys():
                    date_dict[year][doy] = file_name
        # List for VNP46A2 files on the s3
        existing_files = []
        # List for dates of VNP46A2 files on the s3
        existing_files_dates = []
        # Indexer for days in eventual zarr array
        doy_ind = 0
        # For each year of existing files (in order)
        for year in sorted(date_dict.keys(), key=int):
            # For each doy of existing files (in order)
            for doy in sorted(date_dict[year].keys(), key=int):
                # Add file name to the list
                existing_files.append((doy_ind, date_dict[year][doy]))
                # Add file date to the list
                curr_date = datetime.datetime(year=int(year), day=1, month=1) + datetime.timedelta(days=int(doy))
                existing_files_dates.append(np.datetime64(curr_date.strftime("%Y-%m-%d")))
                # Increment indexer
                doy_ind += 1
        # Update
        print(f"Found {date_count} files for tile {tile} in {time_diff(ptime)}. Creating zarr files.")
        ptime = time()
        
        # Creating zarr files for WSF and VNP46A2        
        wsf_root = t_zarr.create_vnp46a2_zarr(str(Path("/app/temp_data/wsf", f"wsf_{tile}.zarr")))

        # Poly zarr dict
        poly_zarrs = {}
        # Poly pixels dict
        poly_pixel_dict = {}
        
        # If the tile is in the tile_poly dict (has any FUA polygons in it)
        if tile in tile_poly.keys():
            # For each polygon in the tile
            for poly_id in tile_poly[tile]:
                # Add key and zarr object
                poly_zarrs[poly_id] = t_zarr.create_vnp46a2_zarr(str(Path("/app/temp_data/fua",
                                                                          f"fua_{poly_id}_{tile}.zarr")))
                # Pixel counter
                pixel_count = 0
                # Pixel lists
                pixel_hs = []
                pixel_vs = []
                # For each pixel x coordinate
                for pix_x in poly_tile_pixel[poly_id][tile].keys():
                    for pix_y in poly_tile_pixel[poly_id][tile][pix_x].keys():
                        # Increment pixel count
                        pixel_count += 1
                        # Transfer the coordinates
                        pixel_hs.append(int(pix_x))
                        pixel_vs.append(int(pix_y))
                # Put the lists in the dict
                poly_pixel_dict[poly_id] = {"pixel_hs": pixel_hs,
                                            "pixel_vs": pixel_vs}
                # Instantiate the datasets for the polygon's zarr
                t_zarr.specify_datasets(poly_zarrs[poly_id], existing_files_dates, pixel_hs, pixel_vs)
        
        # Update
        print(f"Created WSF, VNP, and {len(poly_zarrs.keys())} FUA polygon zarrs for tile {tile} in {time_diff(ptime)}. Creating zarr files.")
        ptime = time()
        
        # Copy the wsf file for the tile from the s3
        rclone.with_config(cfg).run_cmd(command="copy", 
                                        extra_args=[f"ceph:zarr_support/WSF_VNP_masks/wsf_for_vnp_{tile}",
                                                    f"/app/temp_data/"])   
        
               
        # Open the WSF file for the tile
        with open(Path("/app/temp_data", f"wsf_for_vnp_{tile}"), 'rb') as f:
            # Load the numpy array
            wsf_array = pickle.load(f)
            # Make a truthy array
            wsf_truth = np.zeros((2400, 2400))
            # Get the tile's v (row)
            tile_v = int(tile[4:])
            # For each row in wsf_truth
            for row_num, row in enumerate(wsf_truth):
                # Change the row values to the required WSF threshold
                row[:] = c_WSF.get_threshold_for_lat((tile_v * 2400) + row_num, wsf_eq_threshold)
            # Get the non-zero indices where either 2015 and 2019 WSF beats the threshold
            wsf_where = np.nonzero(np.max(wsf_array, 2) > wsf_truth)
            # Instantiate the datasets for the wsf's zarr
            t_zarr.specify_datasets(wsf_root, existing_files_dates, wsf_where[1], wsf_where[0])                               
        
        # Counter for completed days (files)
        completed_days = 0
                
        # Update
        print(f"Preparation complete for {tile} in {np.around(time() - ptime, decimals=2)}s. Processing VNP data.")
        ptime = time()
        
        # Start a ProcessPoolExecutor
        with ProcessPoolExecutor(max_workers=3) as executor:
            for file_chunk in chunk_files(existing_files):
                future_events = [executor.submit(process_time_sync_file,
                                                 cfg,
                                                 target_file,
                                                 poly_pixel_dict,
                                                 wsf_where) for target_file in file_chunk]
                                                 
                for completed_event in as_completed(future_events):
                    # Get the outputs
                    date_obj, poly_results, wsf_results, target_info = completed_event.result()
                    # Convert date to string
                    str_date = date_obj.strftime("%Y-%m-%d")
                    # Get the date row index
                    row_index = target_info[0]
                    # For each data field in the wsf data
                    for data_field in wsf_results.keys():
                        # Transfer the values
                        wsf_root[data_field][row_index, :] = wsf_results[data_field]
                    # For each poly id
                    for poly_id in poly_results.keys():
                        # For each data field
                        for data_field in poly_results[poly_id].keys():
                            # Transfer the values
                            poly_zarrs[poly_id][data_field][row_index, :] = poly_results[poly_id][data_field]
                    # Increment day count
                    completed_days += 1
                    #print(f"Processed {str_date} for {tile}. Day {completed_days} of {date_count}")
        # Update
        print(f"Finished processing for {tile} in {np.around(time() - ptime, decimals=2)}s. Cleaning up and transferring files.")
        ptime = time()
        # Remove WSF file
        os.remove(Path(f"/app/temp_data/wsf_for_vnp_{tile}"))        
        
        # For each poly id
        for poly_id in poly_results.keys():
            # Copy the zarr to the s3
            rclone.with_config(cfg).run_cmd(command="copy", 
                                            extra_args=[str(Path("/app/temp_data/fua",
                                                                 f"fua_{poly_id}_{tile}.zarr")),
                                                        f"ceph:zarrs/fua/fua_{poly_id}_{tile}.zarr/"])
            # Remove zarr file from container
            rmtree(str(Path("/app/temp_data/fua", f"fua_{poly_id}_{tile}.zarr")))
        
        # Copy the wsf zarr to the s3
        rclone.with_config(cfg).run_cmd(command="copy", 
                                        extra_args=[f"/app/temp_data/wsf/wsf_{tile}.zarr",
                                                    f"ceph:zarrs/wsf/wsf_{tile}.zarr/"])
        # Remove WSF zarr
        rmtree(f"/app/temp_data/wsf/wsf_{tile}.zarr")
        
        # Update
        print(f"Finished cleanup for {tile} in {np.around(time() - ptime, decimals=2)}s.") 
        
    print(f"Total time to complete: {np.around(time() - stime, decimals=2)}s.")


if __name__ == "__main__":
    
    # Get the system argument for the tile list
    tile_file = argv[1:][0]   
    
    # Call the main function, hard-coding the chosen WSF equator threshold.    
    main(tile_file, wsf_eq_threshold=0.01)
    