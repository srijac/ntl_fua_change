import zarr


def create_vnp46a2_zarr(storage_path):

    store = zarr.DirectoryStore(storage_path)
    root = zarr.group(store=store, overwrite=True)

    return root


def specify_datasets(zarr_obj, timeseries_days, pixel_hs, pixel_vs):

    zarr_obj.create_dataset("Pixel V",
                            data=pixel_vs,
                            shape=(1, len(pixel_vs)),
                            dtype="uint16")
    zarr_obj.create_dataset("Pixel H",
                            data=pixel_hs,
                            shape=(1, len(pixel_hs)),
                            dtype="uint16")
    zarr_obj.create_dataset("Dates",
                            data=timeseries_days,
                            shape=(1, len(timeseries_days)),
                            dtype="M8[D]")
    zarr_obj.create_dataset("DNB_BRDF-Corrected_NTL",
                            shape=(len(timeseries_days),
                                   len(pixel_vs)),
                            chunks=(100,
                                    len(pixel_vs)),
                            dtype="uint16")
    zarr_obj.create_dataset("Gap_Filled_DNB_BRDF-Corrected_NTL",
                            shape=(len(timeseries_days),
                                   len(pixel_vs)),
                            chunks=(100,
                                    len(pixel_vs)),
                            dtype="uint16")
    zarr_obj.create_dataset("DNB_Lunar_Irradiance",
                            shape=(len(timeseries_days),
                                   len(pixel_vs)),
                            chunks=(100,
                                    len(pixel_vs)),
                            dtype="uint16")
    zarr_obj.create_dataset("Mandatory_Quality_Flag",
                            shape=(len(timeseries_days),
                                   len(pixel_vs)),
                            chunks=(100,
                                    len(pixel_vs)),
                            dtype="uint8")
    zarr_obj.create_dataset("Latest_High_Quality_Retrieval",
                            shape=(len(timeseries_days),
                                   len(pixel_vs)),
                            chunks=(100,
                                    len(pixel_vs)),
                            dtype="uint8")
    zarr_obj.create_dataset("Snow_Flag",
                            shape=(len(timeseries_days),
                             len(pixel_vs)),
                            chunks=(100,
                                    len(pixel_vs)),
                            dtype="uint8")
    zarr_obj.create_dataset("QF_Cloud_Mask",
                            shape=(len(timeseries_days),
                                   len(pixel_vs)),
                            chunks=(100,
                                    len(pixel_vs)),
                            dtype="uint16")